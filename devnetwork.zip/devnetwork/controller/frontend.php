<?php

// Chargement des classes
require_once('model/PostManager.php');
require_once('model/CommentManager.php');

function listPosts()
{
    $postManager = new \Devnetwork\Blog\Model\PostManager();
    $posts = $postManager->getPosts();

    require('views/frontend/listPostsView.php');
}

function post()
{
    $postManager = new \Devnetwork\Blog\Model\PostManager();
    $commentManager = new \Devnetwork\Blog\Model\CommentManager();

    $post = $postManager->getPost($_GET['id']);
    $comments = $commentManager->getComments($_GET['id']);

    require('views/frontend/postView.php');
}

function postcontent()
{
    $postContent = new \Devnetwork\Blog\Model\PostManager();

    $contents = $postContent->postPost();

}

function addComment($postId, $author, $comment)
{
    $commentManager = new \Devnetwork\Blog\Model\CommentManager();

    $affectedLines = $commentManager->postComment($postId, $author, $comment);

    if ($affectedLines === false) {
        throw new Exception('Impossible d\'ajouter le commentaire !');
    }
    else {
        header('Location: index.post.php?action=post&id=' . $postId);
    }
}

function addPost($id, $title, $content)
{
    $postContent = new \Devnetwork\Blog\Model\PostManager();

    $affectedPosts = $postContent->postPost($id, $title, $content);

    if ($affectedPosts === false) {
        throw new Exception('Impossible d\'ajouter l\'article !');
    }
    else {
        header('Location: index.post.php?action=postcontent&id='